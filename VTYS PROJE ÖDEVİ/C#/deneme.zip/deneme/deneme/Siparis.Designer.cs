﻿namespace deneme
{
    partial class Siparis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Siparis));
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.txtsiparistutari = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.siparisAra = new System.Windows.Forms.TextBox();
            this.dataGridViewSiparis = new System.Windows.Forms.DataGridView();
            this.txtsiparistarihi = new System.Windows.Forms.TextBox();
            this.txtsiparisid = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button_listele = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBoxmusteri = new System.Windows.Forms.ComboBox();
            this.comboBoxtir = new System.Windows.Forms.ComboBox();
            this.txtyukleme = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtbosaltma = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtsiparisbilgi = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.txttoplamsiparis = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSiparis)).BeginInit();
            this.SuspendLayout();
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.Lime;
            this.button18.Font = new System.Drawing.Font("Times New Roman", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button18.Location = new System.Drawing.Point(873, 14);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(98, 40);
            this.button18.TabIndex = 119;
            this.button18.Text = "FATURA";
            this.button18.UseVisualStyleBackColor = false;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.button19.Font = new System.Drawing.Font("Times New Roman", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button19.Location = new System.Drawing.Point(777, 14);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(98, 40);
            this.button19.TabIndex = 118;
            this.button19.Text = "SİPARİŞ";
            this.button19.UseVisualStyleBackColor = false;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.Lime;
            this.button20.Font = new System.Drawing.Font("Times New Roman", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button20.Location = new System.Drawing.Point(686, 14);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(98, 40);
            this.button20.TabIndex = 117;
            this.button20.Text = "TIR";
            this.button20.UseVisualStyleBackColor = false;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.Lime;
            this.button12.Font = new System.Drawing.Font("Times New Roman", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button12.Location = new System.Drawing.Point(591, 14);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(98, 40);
            this.button12.TabIndex = 115;
            this.button12.Text = "ÇALIŞAN";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.Lime;
            this.button9.Font = new System.Drawing.Font("Times New Roman", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button9.Location = new System.Drawing.Point(497, 14);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(98, 40);
            this.button9.TabIndex = 114;
            this.button9.Text = "İLETİŞİM";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.Lime;
            this.button10.Font = new System.Drawing.Font("Times New Roman", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button10.Location = new System.Drawing.Point(401, 14);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(98, 40);
            this.button10.TabIndex = 113;
            this.button10.Text = "YÖNETİCİ";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Lime;
            this.button7.Font = new System.Drawing.Font("Times New Roman", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button7.Location = new System.Drawing.Point(305, 13);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(98, 40);
            this.button7.TabIndex = 112;
            this.button7.Text = "ŞUBE";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Lime;
            this.button8.Font = new System.Drawing.Font("Times New Roman", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button8.Location = new System.Drawing.Point(208, 12);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(98, 40);
            this.button8.TabIndex = 111;
            this.button8.Text = "MÜŞTERİLER";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Lime;
            this.button6.Font = new System.Drawing.Font("Times New Roman", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button6.Location = new System.Drawing.Point(111, 12);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(98, 40);
            this.button6.TabIndex = 109;
            this.button6.Text = "OTOPARK";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Lime;
            this.button5.Font = new System.Drawing.Font("Times New Roman", 7.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button5.Location = new System.Drawing.Point(12, 12);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(98, 40);
            this.button5.TabIndex = 108;
            this.button5.Text = "ŞİRKET";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // txtsiparistutari
            // 
            this.txtsiparistutari.Location = new System.Drawing.Point(952, 200);
            this.txtsiparistutari.Name = "txtsiparistutari";
            this.txtsiparistutari.Size = new System.Drawing.Size(216, 22);
            this.txtsiparistutari.TabIndex = 103;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(853, 162);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 19);
            this.label4.TabIndex = 101;
            this.label4.Text = "Tır ID :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(797, 203);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(121, 19);
            this.label5.TabIndex = 100;
            this.label5.Text = "Sipariş Tutarı :";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(38, 75);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(675, 219);
            this.pictureBox1.TabIndex = 98;
            this.pictureBox1.TabStop = false;
            // 
            // siparisAra
            // 
            this.siparisAra.Location = new System.Drawing.Point(38, 316);
            this.siparisAra.Multiline = true;
            this.siparisAra.Name = "siparisAra";
            this.siparisAra.Size = new System.Drawing.Size(235, 25);
            this.siparisAra.TabIndex = 97;
            // 
            // dataGridViewSiparis
            // 
            this.dataGridViewSiparis.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSiparis.Location = new System.Drawing.Point(38, 360);
            this.dataGridViewSiparis.Name = "dataGridViewSiparis";
            this.dataGridViewSiparis.RowHeadersWidth = 51;
            this.dataGridViewSiparis.RowTemplate.Height = 24;
            this.dataGridViewSiparis.Size = new System.Drawing.Size(666, 378);
            this.dataGridViewSiparis.TabIndex = 96;
            this.dataGridViewSiparis.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewSiparis_CellClick);
            this.dataGridViewSiparis.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // txtsiparistarihi
            // 
            this.txtsiparistarihi.Location = new System.Drawing.Point(952, 319);
            this.txtsiparistarihi.Name = "txtsiparistarihi";
            this.txtsiparistarihi.Size = new System.Drawing.Size(216, 22);
            this.txtsiparistarihi.TabIndex = 94;
            // 
            // txtsiparisid
            // 
            this.txtsiparisid.Location = new System.Drawing.Point(952, 75);
            this.txtsiparisid.Name = "txtsiparisid";
            this.txtsiparisid.Size = new System.Drawing.Size(216, 22);
            this.txtsiparisid.TabIndex = 93;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(817, 365);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 19);
            this.label3.TabIndex = 92;
            this.label3.Text = "Müşteri ID :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(797, 319);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 19);
            this.label2.TabIndex = 91;
            this.label2.Text = "Sipariş Tarihi :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(824, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 19);
            this.label1.TabIndex = 90;
            this.label1.Text = "Sipariş ID :";
            // 
            // button_listele
            // 
            this.button_listele.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button_listele.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button_listele.Location = new System.Drawing.Point(989, 714);
            this.button_listele.Name = "button_listele";
            this.button_listele.Size = new System.Drawing.Size(151, 42);
            this.button_listele.TabIndex = 89;
            this.button_listele.Text = "LİSTELE";
            this.button_listele.UseVisualStyleBackColor = false;
            this.button_listele.Click += new System.EventHandler(this.button_listele_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Yellow;
            this.button4.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button4.Location = new System.Drawing.Point(989, 652);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(151, 42);
            this.button4.TabIndex = 88;
            this.button4.Text = "GÜNCELLE";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Red;
            this.button3.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button3.Location = new System.Drawing.Point(989, 590);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(151, 42);
            this.button3.TabIndex = 87;
            this.button3.Text = "SİL";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Lime;
            this.button2.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button2.Location = new System.Drawing.Point(989, 528);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(151, 42);
            this.button2.TabIndex = 86;
            this.button2.Text = "EKLE";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button1.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.Location = new System.Drawing.Point(279, 309);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(85, 38);
            this.button1.TabIndex = 85;
            this.button1.Text = "ARA";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // comboBoxmusteri
            // 
            this.comboBoxmusteri.FormattingEnabled = true;
            this.comboBoxmusteri.Location = new System.Drawing.Point(952, 360);
            this.comboBoxmusteri.Name = "comboBoxmusteri";
            this.comboBoxmusteri.Size = new System.Drawing.Size(216, 24);
            this.comboBoxmusteri.TabIndex = 120;
            // 
            // comboBoxtir
            // 
            this.comboBoxtir.FormattingEnabled = true;
            this.comboBoxtir.Location = new System.Drawing.Point(952, 157);
            this.comboBoxtir.Name = "comboBoxtir";
            this.comboBoxtir.Size = new System.Drawing.Size(216, 24);
            this.comboBoxtir.TabIndex = 121;
            this.comboBoxtir.SelectedIndexChanged += new System.EventHandler(this.comboBoxtir_SelectedIndexChanged);
            // 
            // txtyukleme
            // 
            this.txtyukleme.Location = new System.Drawing.Point(952, 243);
            this.txtyukleme.Name = "txtyukleme";
            this.txtyukleme.Size = new System.Drawing.Size(216, 22);
            this.txtyukleme.TabIndex = 125;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(800, 243);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(118, 19);
            this.label7.TabIndex = 124;
            this.label7.Text = "Yükleme Yeri :";
            // 
            // txtbosaltma
            // 
            this.txtbosaltma.Location = new System.Drawing.Point(952, 281);
            this.txtbosaltma.Name = "txtbosaltma";
            this.txtbosaltma.Size = new System.Drawing.Size(216, 22);
            this.txtbosaltma.TabIndex = 128;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.Location = new System.Drawing.Point(795, 281);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(123, 19);
            this.label8.TabIndex = 127;
            this.label8.Text = "Boşaltma Yeri :";
            // 
            // txtsiparisbilgi
            // 
            this.txtsiparisbilgi.Location = new System.Drawing.Point(952, 115);
            this.txtsiparisbilgi.Name = "txtsiparisbilgi";
            this.txtsiparisbilgi.Size = new System.Drawing.Size(216, 22);
            this.txtsiparisbilgi.TabIndex = 130;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.Location = new System.Drawing.Point(817, 116);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(101, 19);
            this.label9.TabIndex = 129;
            this.label9.Text = "Sipariş Adı :";
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.Red;
            this.button11.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button11.Location = new System.Drawing.Point(1071, 0);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(159, 55);
            this.button11.TabIndex = 131;
            this.button11.Text = "ÇIKIŞ";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // txttoplamsiparis
            // 
            this.txttoplamsiparis.Location = new System.Drawing.Point(952, 403);
            this.txttoplamsiparis.Name = "txttoplamsiparis";
            this.txttoplamsiparis.Size = new System.Drawing.Size(105, 22);
            this.txttoplamsiparis.TabIndex = 132;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.Location = new System.Drawing.Point(752, 403);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(172, 19);
            this.label10.TabIndex = 133;
            this.label10.Text = "Toplam Sipariş Adedi:";
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.Lime;
            this.button13.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button13.Location = new System.Drawing.Point(1071, 397);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(97, 32);
            this.button13.TabIndex = 134;
            this.button13.Text = "GÖSTER";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // Siparis
            // 
            this.AcceptButton = this.button_listele;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1232, 803);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txttoplamsiparis);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.txtsiparisbilgi);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtbosaltma);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtyukleme);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.comboBoxtir);
            this.Controls.Add(this.comboBoxmusteri);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.txtsiparistutari);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.siparisAra);
            this.Controls.Add(this.dataGridViewSiparis);
            this.Controls.Add(this.txtsiparistarihi);
            this.Controls.Add(this.txtsiparisid);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button_listele);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "Siparis";
            this.Text = "Siparis";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Siparis_FormClosing);
            this.Load += new System.EventHandler(this.Siparis_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSiparis)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox txtsiparistutari;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox siparisAra;
        private System.Windows.Forms.DataGridView dataGridViewSiparis;
        private System.Windows.Forms.TextBox txtsiparistarihi;
        private System.Windows.Forms.TextBox txtsiparisid;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_listele;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboBoxmusteri;
        private System.Windows.Forms.ComboBox comboBoxtir;
        private System.Windows.Forms.TextBox txtyukleme;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtbosaltma;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtsiparisbilgi;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.TextBox txttoplamsiparis;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button13;
    }
}